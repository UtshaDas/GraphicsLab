#include<windows.h>
#include <stdio.h>
#include<GL/glut.h>
float fovy=45.0f;
float aspect=1.0f;
float farr=5.0f;
float nearr=20.0f;

float ex=0.0;
float ey=0.0;
float ez=5.0;

float cx=0.0;
float cy=0.0;
float cz=0.0;

float upx=0.0;
float upy=1.0;
float upz=1.0;

void init(void)
{
    glClearColor (0.0, 0.0, 0.0, 0.0);
    glShadeModel (GL_FLAT);
}
void cubedesign(void)
{
     glBegin(GL_QUADS);                // Begin drawing the color cube with 6 quads
      // Top face (y = 1.0f)
      // Define vertices in counter-clockwise (CCW) order with normal pointing out
      glColor3f(0.0f, 1.0f, 0.0f);     // Green
      glVertex3f( 1.0f, 1.0f, -1.0f);
      glVertex3f(-1.0f, 1.0f, -1.0f);
      glVertex3f(-1.0f, 1.0f,  1.0f);
      glVertex3f( 1.0f, 1.0f,  1.0f);

      // Bottom face (y = -1.0f)
      glColor3f(1.0f, 0.5f, 0.0f);     // Orange
      glVertex3f( 1.0f, -1.0f,  1.0f);
      glVertex3f(-1.0f, -1.0f,  1.0f);
      glVertex3f(-1.0f, -1.0f, -1.0f);
      glVertex3f( 1.0f, -1.0f, -1.0f);

      // Front face  (z = 1.0f)
      glColor3f(1.0f, 0.0f, 0.0f);     // Red
      glVertex3f( 1.0f,  1.0f, 1.0f);
      glVertex3f(-1.0f,  1.0f, 1.0f);
      glVertex3f(-1.0f, -1.0f, 1.0f);
      glVertex3f( 1.0f, -1.0f, 1.0f);

      // Back face (z = -1.0f)
      glColor3f(1.0f, 1.0f, 0.0f);     // Yellow
      glVertex3f( 1.0f, -1.0f, -1.0f);
      glVertex3f(-1.0f, -1.0f, -1.0f);
      glVertex3f(-1.0f,  1.0f, -1.0f);
      glVertex3f( 1.0f,  1.0f, -1.0f);

      // Left face (x = -1.0f)
      glColor3f(0.0f, 0.0f, 1.0f);     // Blue
      glVertex3f(-1.0f,  1.0f,  1.0f);
      glVertex3f(-1.0f,  1.0f, -1.0f);
      glVertex3f(-1.0f, -1.0f, -1.0f);
      glVertex3f(-1.0f, -1.0f,  1.0f);

      // Right face (x = 1.0f)
      glColor3f(1.0f, 0.0f, 1.0f);     // Magenta
      glVertex3f(1.0f,  1.0f, -1.0f);
      glVertex3f(1.0f,  1.0f,  1.0f);
      glVertex3f(1.0f, -1.0f,  1.0f);
      glVertex3f(1.0f, -1.0f, -1.0f);
   glEnd();  // End of drawing color-cube
   glFlush ();
   glutSwapBuffers();
}
void display(void)
{
    glClear (GL_COLOR_BUFFER_BIT);
    glColor3f (1.0, 1.0, 1.0);
    //glEnable(GL_DEPTH_TEST);
    //glLoadIdentity (); /* clear the matrix */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity (); /* clear the matrix */
    gluPerspective(fovy,aspect,nearr,farr);
    //glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    /* viewing transformation */
    gluLookAt (ex, ey, ez, cx, cy, cz, upx, upy, upz);
    //glScalef (1.0, 1.0, 1.0); /* modeling transformation */
    //glutWireCube (1.0);
    cubedesign();

//    glTranslatef(0.0, 0.0, -1.0);
//    glRotatef(60, 1.0, 0.0, 0.0);
//    glRotatef(-20, 0.0, 0.0, 1.0);

}

//void reshape (int w, int h)
//{
//    glViewport (0, 0, (GLsizei) w, (GLsizei) h);
//    glMatrixMode (GL_PROJECTION);
//    glLoadIdentity ();
//    //glPushMatrix();
//    //glFrustum (-1.0, 1.0, -1.0, 1.0, 1.5, 20.0);
//    printf("fovy=%f\n",fovy);
//    printf("aspect=%f\n",aspect);
//    printf("far =%f\n",farr);
//    printf("Near =%f\n",nearr);
//    gluPerspective(fovy,aspect,nearr,farr);
//   // glPushMatrix();
//    glMatrixMode (GL_MODELVIEW);
//}
void Keyboard(unsigned char c, int x, int y)
{
    for(int z=65;z<1000;z++){
    c=rand()%(78+1-65)+65;
    printf("%d\n",c);
    glLoadIdentity();
    switch(c)
    {
    case 65:
        glClear(GL_COLOR_BUFFER_BIT);
        fovy=fovy+5.0;
       // printf("%f\n",fovy);
        //glutDisplayFunc(display);
        //glPushMatrix();
        //printf("Display called\n");
        //glutReshapeFunc(reshape);
        //printf("RESHAPE called\n");
        //glPopMatrix();
        glutPostRedisplay();
        break;
    case 66:
        glClear(GL_COLOR_BUFFER_BIT);
        fovy=fovy-5.0;
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);
        glutPostRedisplay();
        break;
    case 67:
        glClear(GL_COLOR_BUFFER_BIT);
        aspect=aspect*2;
        glPushMatrix();
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);
//        glPopMatrix();
        glutPostRedisplay();
        break;
    case 68:
        glClear(GL_COLOR_BUFFER_BIT);
        aspect=aspect/2;
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);
        glutPostRedisplay();
        break;

    case 69:
        glClear(GL_COLOR_BUFFER_BIT);
        nearr=nearr+2;
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);
        glutPostRedisplay();
        break;
    case 70:
        glClear(GL_COLOR_BUFFER_BIT);
        nearr=nearr-2;
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);

        glutPostRedisplay();
        break;
    case 71:
        glClear(GL_COLOR_BUFFER_BIT);
        farr=farr+2;
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);
        glutPostRedisplay();
        break;
    case 72:
        glClear(GL_COLOR_BUFFER_BIT);
        farr=farr-2;
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);
        glutPostRedisplay();
        break;
    case 73:
        glClear(GL_COLOR_BUFFER_BIT);
        for(int i=0;i<=100;i++){
            ex=ex+0.05;
            ey=ey+0.05;
            ez=ez+0.05;
            glutPostRedisplay();
        }
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);

        break;

    case 74:
        glClear(GL_COLOR_BUFFER_BIT);
        for(int j=0;j<=100;j++){
            ex=ex-0.05;
            ey=ey-0.05;
            ez=ez-0.05;
            glutPostRedisplay();
        }
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);

        break;
    case 75:
        glClear(GL_COLOR_BUFFER_BIT);
        for(int k=0;k<=100;k++){
            cx=cx+0.05;
            cy=cy+0.05;
            cz=cz+0.05;
            glutPostRedisplay();
        }
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);

        break;
    case 76:
        glClear(GL_COLOR_BUFFER_BIT);
        for(int l=0;l<=100;l++){
            cx=cx-0.05;
            cy=cy-0.05;
            cz=cz-0.05;
            glutPostRedisplay();
        }
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);

        break;

    case 77:
        glClear(GL_COLOR_BUFFER_BIT);
        for(int m=0;m<=100;m++){
            upx=upx+0.05;
            upy=upy+0.05;
            upz=upz+0.05;
            glutPostRedisplay();
        }
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);

        break;
    case 78:
        glClear(GL_COLOR_BUFFER_BIT);
        for(int n=0;n<=100;n++){
            upx=upx-0.05;
            upy=upy-0.05;
            upz=upz-0.05;
            glutPostRedisplay();
        }
//        glutDisplayFunc(display);
//        glutReshapeFunc(reshape);

        break;
    }
    Sleep(1);
}

}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (500, 500);
    glutInitWindowPosition (100, 100);
    glutCreateWindow (argv[0]);
    init ();
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glutDisplayFunc(display);
    //glutReshapeFunc(reshape);
    //scanf("%f",&aspect);
    //glutReshapeFunc(reshape);
    glutKeyboardFunc(Keyboard);//press any key
    glutMainLoop();
return 0;
}
